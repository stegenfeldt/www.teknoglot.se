﻿## Using parameters for RMS and wildcard search
param(
	[string]$rootManagementServer = $(Read-Host -Prompt "Root Management Server"),
	[string]$filterAgents = $(Read-Host -Prompt "ACS Forwarder name (wildcard)"),
	[switch]$UseCredentials
)

## Make sure the $rootManagementServer variable is defined
while (-not $rootManagementServer) {
	Write-Host "`nRoot Management Server MUST be defined!" -ForegroundColor Red
	[string]$rootManagementServer = $(Read-Host -Prompt "Root Management Server")
}

if ($UseCredentials -eq $true) {
	$taskCredentials = Get-Credential
}

$startLocation = Get-Location
$checkPSSnapin = Get-PSSnapin | where {$_.Name -eq "Microsoft.EnterpriseManagement.OperationsManager.Client"}
if ($checkPSSnapin -eq $null) {
	Add-PSSnapin "Microsoft.EnterpriseManagement.OperationsManager.Client"
}
$result = Set-Location "OperationsManagerMonitoring::"
$result = New-ManagementGroupConnection -ConnectionString:$rootManagementServer
$result = Set-Location $rootManagementServer

$acsForwarderClass = Get-MonitoringClass -Name "Microsoft.SystemCenter.ACS.Forwarder"
$agentNames = Get-MonitoringObject -monitoringclass:$acsForwarderClass | where {$_.Path -like $filterAgents} | Select Path
$successfulTasks = @()
$skippedTasks = @()
$failedTasks = @()

$monitoringClass = Get-MonitoringClass -Name "Microsoft.SystemCenter.Agent"
if ($agentNames -ne $null) {
	Write-Host "`nFound"$agentNames.Count"ACS forwarders with wildcard $filterAgents"
	Write-Host "`n`nWaiting for 5 seconds to give you a chance to abort!`n"
	Start-Sleep -Seconds 5
	Write-Host "Time's UP!`n`n"
	$agentNames | ForEach-Object {
		$agentName = $_.Path
		Write-Host "Disabling Audit Collection on" $agentName
		$monitoringObject = Get-MonitoringObject -monitoringclass:$monitoringClass | where {$_.DisplayName -like $agentName}
		$agentTask = $monitoringObject | Get-Task | where {$_.Name -eq "Microsoft.SystemCenter.DisableAuditCollectionService"}
		if ($monitoringObject.IsAvailable -eq $true) {
			if ($credentials -eq $null) {
				$result = Start-Task -Task $agentTask -TargetMonitoringObject $monitoringObject
			} else {
				$result = Start-Task -Task $agentTask -TargetMonitoringObject $monitoringObject -Credential $taskCredentials
			}
			if ($result.Status -eq "Succeeded") {
				Write-Host "Operation Successful!" -ForegroundColor Green
				Write-Host `n
				$successfulTasks += $agentName
			} else {
				Write-Host "Operation failed." -ForegroundColor Red
				Write-Host $result.ErrorMessage
				Write-Host `n
				$failedTasks += $agentName
			}
		} else {
			Write-Host "The agent is unavailable, Skipping!"
			Write-Host `n
			$skippedTasks += $agentName
		}
	}
	Write-Host "Summary"
	Write-Host "`tSuccessful:`t"$successfulTasks.count
	Write-Host "`tFailed:`t`t"$failedTasks.count
	Write-Host "`tSkipped:`t"$skippedTasks.count
} else {
	Write-Host "`nNo ACS Forwarders found using wildcard $filterAgents"
}

Set-Location $startLocation

